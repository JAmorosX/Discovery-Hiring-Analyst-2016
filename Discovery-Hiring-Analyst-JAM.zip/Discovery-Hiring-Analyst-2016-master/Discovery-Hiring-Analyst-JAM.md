---
title: "Discovery - Data Analyst task"
author: "Jaume Amoros"
date: "8 de agosto de 2019"
output: html_document
---









***
***
### Executive summary

* This report shows data from **2016-03-01** to **2016-03-08**.

* The overall clickthrough rate was of **29.9%**. The minimum during theses days was of 29.22% and the maximum of tal 30.67%. 

* The most visited result is the one apearing on the position **1**, which is visited on the **63.3%** of searches.

* The overall zero result rate was of **18.4%**.  The minimum during theses days was of 17.62% and the maximum of tal 19.37%. 

***
***

#### Clickthrough rate

The clickthrough rate on the overall observed period is of 29.9%. It varies along the days as shown in the table:


|Day of the week |Date       |Clickthrough rate |
|:---------------|:----------|:-----------------|
|Tuesday         |2016-03-01 |29.23%            |
|Wednesday       |2016-03-02 |29.22%            |
|Thursday        |2016-03-03 |29.92%            |
|Friday          |2016-03-04 |30.67%            |
|Saturday        |2016-03-05 |30.21%            |
|Sunday          |2016-03-06 |30.55%            |
|Monday          |2016-03-07 |29.56%            |
|Tuesday         |2016-03-08 |29.92%            |



The clickthrough rate on the group *a* was of 35.3% and the clickthrough rate of the group *b* was of 18.6%. This is a difference of 16.6% and is  statistically significant ($\chi^2$ = 3212.72, *p* < 0.001, CI95% = 0.161 to 0.172).

The distribution of clickthrough rate between the groups can be seen on the next plot.

![](figure/Plot Clickthourgh rate-1.png)

Most sessions tend to the extremes of 0 and 100% of clickthrough rate. While on group *a*, the rate is more likely to take values between 0 and 100, on group *b* they are gathered nearly exclusively at the extremes.

***

### First visited results

After every search, the user may visit one or more of the pages found. The most common visited page is the one appearing on the 1 position, which is visited the 63.3% of searches. 

During the 8 days evaluated, the distribution of the first visited page per its posiiton on the search is as shown on the plot:

![](figure/Plot Distribution first visited page-1.png)

There is not much difference along time on the first visited page after a search.

***

### Zero Result rate

The zero result rate on the overall observed period is of 18.4%. It varies along the days as shown in the table:


|Day of the week |Date       |Zero Result rate |
|:---------------|:----------|:----------------|
|Tuesday         |2016-03-01 |18.76%           |
|Wednesday       |2016-03-02 |18.99%           |
|Thursday        |2016-03-03 |17.97%           |
|Friday          |2016-03-04 |18.08%           |
|Saturday        |2016-03-05 |18.49%           |
|Sunday          |2016-03-06 |17.62%           |
|Monday          |2016-03-07 |18.20%           |
|Tuesday         |2016-03-08 |19.37%           |



The clickthrough rate on the group *a* was of 18.4% and the clickthrough rate of the group *b* was of 18.6%. This is a difference of 0.257% and is not statistically significant ($\chi^2$ = 1.29, *p* =0.255, CI95% = -0.007 to 0.002).

The distribution of zero result rate between the groups can be seen on the next plot.

![](figure/Plot Zero Result rate-1.png)

On most searches from both group sessions *a* and *b* the chances of getting zero result is very low. While on group *b* the sessions are gathered around 0 and 100% zero result rate, on group *a* they are more distributed along the possiblities. That may indicate that sessions of group *a* tend to do more searches, hence, are plausible to obtain different values of zero result rate per session.


***

### Session length

Session length is computed as the difference between the first and last timestamp on a session\*. Let's check the relationship between lentgh of the session and number of results found on the searches.

![](figure/Plot length session-1.png)


\* Time continuity correction of 5 seconds.

***




